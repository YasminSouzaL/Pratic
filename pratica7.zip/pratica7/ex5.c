/*Codifique, compile e execute um programa em C que crie uma estrutura Endereço com os
seguintes campos: nome da rua, número, cidade, estado e cep. Em seguida defina uma variável
do tipo da estrutura Endereço e leia os valores para cada um dos seus campos. Ao final, imprima
os valores armazenados em cada campo da estrutura na tela.*/
#include <stdio.h>
#include <stdlib.h>
struct Endereco{
    char rua[50], cidade[50], estado[50], cep[50];
    int numero;
};

int main(){
    struct Endereco endereco;
    printf("Digite o nome da rua: ");
    gets(endereco.rua);
    printf("Digite o numero: ");
    scanf("%d", &endereco.numero);
    getchar();
    printf("Digite a cidade: ");
    gets(endereco.cidade);
    printf("Digite o estado: ");
    gets(endereco.estado);
    printf("Digite o cep: ");
    gets(endereco.cep);
    printf("Rua: %s\nNumero: %d\nCidade: %s\nEstado: %s\nCEP: %s\n", endereco.rua, endereco.numero, endereco.cidade, endereco.estado, endereco.cep);
    return 0;
}