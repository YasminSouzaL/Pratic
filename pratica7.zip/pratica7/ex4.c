/*Codifique, compile e execute um programa em C que crie uma estrutura Hora com os seguintes
campos: hora, minuto e segundo. Em seguida defina uma variável do tipo da estrutura Hora e leia
os valores para cada um dos seus campos. Ao final, imprima os valores armazenados em cada
campo da estrutura na tela*/
#include <stdio.h>
#include <stdlib.h>
struct Hora{
    int hora, minuto, segundo;
};

int main(){
    struct Hora horario;
    printf("Digite a hora: ");
    scanf("%d", &horario.hora);
    printf("Digite o minuto: ");
    scanf("%d", &horario.minuto);
    printf("Digite o segundo: ");
    scanf("%d", &horario.segundo);
    printf("Hora: %d\nMinuto: %d\nSegundo: %d\n", horario.hora, horario.minuto, horario.segundo);
    return 0;
}