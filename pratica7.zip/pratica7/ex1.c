/*
Codifique, compile e execute um programa em C que leia o nome completo do usuário
e armazene em um vetor de 50 posições. Em seguida, o sistema deve exibir o tamanho
da string fornecida. (Não utilize funções prontas da biblioteca string.h)
*/
#include <stdio.h>
#include <stdlib.h>
int main(){
    char nome[50];
    int i = 0;
    printf("Digite seu nome completo: ");
    scanf("%s", nome);
    while(nome[i] != '\0'){
        i++;
    }
    printf("O tamanho da string fornecida eh: %d\n", i);
    return 0;
}
