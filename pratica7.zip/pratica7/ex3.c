/* Faça um programa que preencha um vetor com os modelos de 5 carros (exemplos de
modelos: Fusca, Gol, Vectra, etc.). Preencha outro vetor com o consumo desses carros,
isto é, quantos quilômetros cada um deles faz com um litro de combustível. Calcule e
mostre:
(a) O modelo de carro mais econômico;
(b) Quantos litros de combustível cada um dos carros cadastrados consomem para
percorrer uma distância de 1.000 quilômetros.
Entrada
A entrada de seu programa deve ser um vetor de 5 posições que armazene 5 modelos de
carros com tamanho máximo de 20 caracteres por modelo. E outro vetor, do tipo float, que
armazene o consumo desses 5 carros.
Saída
A saída de seu programa deve ser qual o modelo de carro mais econômico e o nome e
quantos litros de combustível cada um dos carros cadastrados consomem ao percorrerem
1.000 quilômetros, a saída referente à quilometragem percorrida deverá ser com duas
casas decimais e separada com quebra de linha no final da sentença. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
    char modelos[5][30];
    float consumo[5], menorConsumo = 0;
    int i, j, maisEconomico;
    for(i = 0; i < 5; i++){
        printf("Digite o modelo do carro %d: ", i+1);
        gets(modelos[i]);
        printf("Digite o consumo do carro %d: ", i+1);
        scanf("%f", &consumo[i]);
        getchar();
    }
    for(i = 0; i < 5; i++){
        if(i == 0){
            menorConsumo = consumo[i];
            maisEconomico = i;
        }else{
            if(consumo[i] < menorConsumo){
                menorConsumo = consumo[i];
                maisEconomico = i;
            }
        }
    }
    printf("O modelo mais economico eh: %s\n", modelos[maisEconomico]);
}