/*Codifique, compile e execute um programa em C que receba duas palavras digitadas
pelo usuário e verifique se elas são iguais ou não. (Não utilize funções prontas da
biblioteca string.h)*/
#include <stdio.h>
#include <stdlib.h>
int main(){
    char palavra1[50], palavra2[50];
    int i = 0, j = 0, flag = 0;
    printf("Digite a primeira palavra: ");
    gets(palavra1);
    printf("Digite a segunda palavra: ");
    gets(palavra2)
    while(palavra1[i] != '\0' && palavra2[j] != '\0'){
        if(palavra1[i] != palavra2[j]){
            flag = 1;
            break;
        }
        i++;
        j++;
    }
    if(flag == 0){
        printf("As palavras sao iguais.\n");
    }else{
        printf("As palavras sao diferentes.\n");
    }
    return 0;
}