/*Codifique, compile e execute um programa em C que crie uma estrutura Pessoa com os
seguintes campos: nome, sexo, peso, data de nascimento e endereço. Em seguida defina uma
variável do tipo da estrutura Pessoa e leia os valores para cada um dos seus campos. Ao final,
imprima os valores armazenados em cada campo da estrutura na tela. Obs: Crie uma nova
estrutura para Data e utilize a estrutura Endereço implementada no exercício anterior*/

#include <stdio.h>
#include <stdlib.h>
struct Data{
    int dia, mes, ano;
};

struct Endereco{
    char rua[50], cidade[50], estado[50], cep[50];
    int numero;
};

struct Pessoa{
    char nome[50], sexo[50];
    float peso;
    struct Data dataNascimento;
    struct Endereco endereco;
};

int main(){
    struct Pessoa pessoa;
    printf("Digite o nome: ");
    gets(pessoa.nome);
    printf("Digite o sexo: ");
    gets(pessoa.sexo);
    printf("Digite o peso: ");
    scanf("%f", &pessoa.peso);
    getchar();
    printf("Digite o dia de nascimento: ");
    scanf("%d", &pessoa.dataNascimento.dia);
    getchar();
    printf("Digite o mes de nascimento: ");
    scanf("%d", &pessoa.dataNascimento.mes);
    getchar();
    printf("Digite o ano de nascimento: ");
    scanf("%d", &pessoa.dataNascimento.ano);
    getchar();
    printf("Digite o nome da rua: ");
    gets(pessoa.endereco.rua);
    printf("Digite o numero: ");
    scanf("%d", &pessoa.endereco.numero);
    getchar();
    printf("Digite a cidade: ");
    gets(pessoa.endereco.cidade);
    printf("Digite o estado: ");
    gets(pessoa.endereco.estado);
    printf("Digite o cep: ");
    gets(pessoa.endereco.cep);
    printf("Nome: %s\nSexo: %s\nPeso: %.2f\nData de nascimento: %d/%d/%d\nRua: %s\nNumero: %d\nCidade: %s\nEstado: %s\nCEP: %s\n", pessoa.nome, pessoa.sexo, pessoa.peso, pessoa.dataNascimento.dia, pessoa.dataNascimento.mes, pessoa.dataNascimento.ano, pessoa.endereco.rua, pessoa.endereco.numero, pessoa.endereco.cidade, pessoa.endereco.estado, pessoa.endereco.cep);
    return 0;
    
}