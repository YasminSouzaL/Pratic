/*2.a) Reescreva o programa da questão anterior com a função strcmp().
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
    char palavra1[50], palavra2[50];
    int i = 0, j = 0, flag = 0;
    printf("Digite a primeira palavra: ");
    gets(palavra1)
    printf("Digite a segunda palavra: ");
    gets(palavra2)
    if(strcmp(palavra1, palavra2) == 0){
        printf("As palavras sao iguais.\n");
    }else{
        printf("As palavras sao diferentes.\n");
    }
    return 0;
}