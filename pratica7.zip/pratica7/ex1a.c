/*Reescreva o programa da questão anterior com a função strlen().*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
    char nome[50];
    int i = 0;
    printf("Digite seu nome completo: ");
    gets(nome);
    printf("O tamanho da string fornecida eh: %d\n", strlen(nome));
    return 0;
}
