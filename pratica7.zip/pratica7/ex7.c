/*Codifique, compile e execute um programa em C que crie uma estrutura representando os
alunos do curso de Programação. A estrutura deve conter a matrícula do aluno, nome, nota da
primeira prova, nota da segunda prova e nota da terceira prova. O programa deve executar as
seguintes ações:
a- permitir ao usuário entrar com os dados de 5 alunos
b- encontrar o aluno com maior nota da primeira prova
c- encontrar o aluno com maior média geral
d- encontrar o aluno com menor média geral
e- para cada aluno armazenado na estrutura diga se ele foi aprovado ou reprovado, considerando
o valor 60 para aprovação.
Entrada
A entrada do seu programa deve ser a matrícula, o nome, a nota da primeira prova do tipo float, a
nota da segunda prova do tipo float e a nota da terceira prova de 5 alunos, também do tipo float.
Saída
A saída deverá ser o nome do aluno com maior nota na primeira prova com pulo de linha no final
da sentença, o nome do aluno com maior média geral com pulo de linha no final da sentença, o
nome do aluno com menor média geral, com pulo de linha no final da sentença e para cada um
dos 5 alunos imprimir Aprovado caso tenha média geral maior ou igual a 60 ou imprimir
Reprovado caso tenha uma média geral menor que 60.*/
#include <stdio.h>
#include <stdlib.h>
struct Aluno{
    int matricula;
    char nome[50];
    float nota1, nota2, nota3;
};
int main(){
    struct Aluno aluno[5];
    int i, maiorNota1 = 0, maiorMedia = 0, menorMedia = 0;
    float media[5];
    for(i = 0; i < 5; i++){
        printf("Digite a matricula do aluno: ");
        scanf("%d", &aluno[i].matricula);
        getchar();
        printf("Digite o nome do aluno: ");
        gets(aluno[i].nome);
        printf("Digite a nota da primeira prova: ");
        scanf("%f", &aluno[i].nota1);
        printf("Digite a nota da segunda prova: ");
        scanf("%f", &aluno[i].nota2);
        printf("Digite a nota da terceira prova: ");
        scanf("%f", &aluno[i].nota3);
        media[i] = (aluno[i].nota1 + aluno[i].nota2 + aluno[i].nota3) / 3;
        if(aluno[i].nota1 > aluno[maiorNota1].nota1){
            maiorNota1 = i;
        }
        if(media[i] > media[maiorMedia]){
            maiorMedia = i;
        }
        if(media[i] < media[menorMedia]){
            menorMedia = i;
        }
    }
    printf("Aluno com maior nota na primeira prova: %s\n", aluno[maiorNota1].nome);
    printf("Aluno com maior media geral: %s\n", aluno[maiorMedia].nome);
    printf("Aluno com menor media geral: %s\n", aluno[menorMedia].nome);
    for(i = 0; i < 5; i++){
        if(media[i] >= 60){
            printf("Aluno %s aprovado\n", aluno[i].nome);
        }else{
            printf("Aluno %s reprovado\n", aluno[i].nome);
        }
    }
    return 0;
}